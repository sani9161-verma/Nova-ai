NOVA ONE PWA — Android installable web app

WHAT THIS PACKAGE DOES
- Adds a Web App Manifest, service worker and 192/512 app icons.
- Makes the NOVA ONE frontend installable from a supported Android browser once hosted over HTTPS.
- Caches the app shell for repeat/offline opening. Live AI requests are NOT cached.

IMPORTANT
- Acode's local preview / file:// cannot install a PWA. A secure HTTPS website is required.
- This package is the PWA frontend. The Python AI backend in the v1.1 package must be deployed separately to use real AI.
- The current frontend calls /api/chat on the same origin. If frontend and backend are hosted separately, configure a secure backend URL and CORS before connecting them.
- Do not put API keys in index.html, manifest.json, sw.js or any public file.
- Free hosting quotas and terms can change. Never enable paid billing without permission.

ANDROID-FRIENDLY DEPLOYMENT (GitHub Pages)
1. Create/sign in to GitHub in Chrome.
2. Create a new public repository, e.g. nova-one-pwa.
3. Upload these files to the repository root: index.html, manifest.json, sw.js, icon-192.png, icon-512.png.
4. In repository Settings > Pages, select Deploy from a branch, choose main and /(root), then Save.
5. Wait for the Pages URL to become available. Open the HTTPS URL in Chrome on Android.
6. Chrome menu (three dots) > Install app or Add to Home screen > Install.
7. Find NOVA ONE on your Home Screen and open it.

TEST
- Open the hosted site, then Chrome DevTools (desktop) or browser install UI.
- The app shell can open offline after its first successful load.
- AI chat needs the backend and internet connection.

This package does not contain an APK. PWA installation creates an app-like web app without Play Store.
